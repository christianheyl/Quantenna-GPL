
The SigmaWTG is used for Sigma PC-ENDPOINT (a traffic generator sitting behind
APs on wired side). If you work on DUT, you should ignore this folder
